import json
import logging
import os
import re
from typing import Any

import requests
from requests.exceptions import RequestException, Timeout
from config import (api_key)

logger = logging.getLogger(__name__)

AEMET_BASE_URL = "https://opendata.aemet.es/opendata/api"
PLAYA_ENDPOINT_TEMPLATE = f"{AEMET_BASE_URL}/prediccion/especifica/playa/{{id_playa}}"
ID_PLAYA_REGEX = re.compile(r"^\d{7}$")


def _decodificar_json_aemet(response: requests.Response) -> Any:
    """
    Decodifica la respuesta JSON de AEMET, contemplando casos en los que
    el servidor no declara UTF-8 explícitamente y usa codificación Latin-1.
    """
    if response.encoding is None and response.apparent_encoding:
        response.encoding = response.apparent_encoding
    try:
        return response.json()
    except ValueError:
        texto = response.content.decode("latin-1", errors="replace")
        return json.loads(texto)


def obtener_prediccion_playa(
    id_playa: str,
    timeout: float = 10.0,
    session: requests.Session | None = None,
) -> dict[str, Any] | list[Any] | None:
    """
    Realiza el doble salto contra AEMET OpenData para un id_playa de 7 dígitos
    y devuelve el JSON final con la predicción.

    Ante errores HTTP (404, 429, etc.), timeouts o respuestas inválidas,
    registra un mensaje WARNING y devuelve None sin lanzar excepciones.
    """
    playa_id = str(id_playa).strip().zfill(7) if str(id_playa).strip().isdigit() else str(id_playa).strip()
    if not ID_PLAYA_REGEX.match(playa_id):
        logger.warning(
            "id_playa no válido ('%s'): se requieren exactamente 7 dígitos.",
            id_playa,
        )
        return None

    clave_api = api_key 
    if not clave_api:
        logger.warning(
            "Falta api_key (parámetro o variable de entorno AEMET_API_KEY) para consultar playa %s.",
            playa_id,
        )
        return None

    url_inicial = PLAYA_ENDPOINT_TEMPLATE.format(id_playa=playa_id)
    headers = {
        "api_key": clave_api,
        "Accept": "application/json",
    }
    cliente_http = session if session is not None else requests

    try:
        # 1. Primer salto: obtiene los metadatos y la URL temporal en 'datos'
        resp_paso1 = cliente_http.get(url_inicial, headers=headers, timeout=timeout)

        if resp_paso1.status_code == 429:
            retry_after = resp_paso1.headers.get("Retry-After", "no indicado")
            logger.warning(
                "Límite de peticiones excedido (HTTP 429) en primer salto para playa %s (Retry-After: %s).",
                playa_id,
                retry_after,
            )
            return None

        if resp_paso1.status_code == 404:
            logger.warning(
                "Recurso no encontrado (HTTP 404) en AEMET para id_playa=%s.",
                playa_id,
            )
            return None

        resp_paso1.raise_for_status()

        meta = _decodificar_json_aemet(resp_paso1)
        if not isinstance(meta, dict):
            logger.warning(
                "Formato inesperado en el primer salto para playa %s: se esperaba un objeto JSON.",
                playa_id,
            )
            return None

        estado_aemet = meta.get("estado")
        if estado_aemet is not None and int(estado_aemet) != 200:
            logger.warning(
                "AEMET respondió con estado %s para playa %s: %s",
                estado_aemet,
                playa_id,
                meta.get("descripcion", "Sin descripción"),
            )
            return None

        url_datos = meta.get("datos")
        if not url_datos or not isinstance(url_datos, str):
            logger.warning(
                "La respuesta de AEMET para playa %s no incluye la URL 'datos': %s",
                playa_id,
                meta,
            )
            return None

        # 2. Segundo salto: descarga el JSON definitivo desde 'datos'
        resp_paso2 = cliente_http.get(url_datos, timeout=timeout)

        if resp_paso2.status_code == 429:
            logger.warning(
                "Límite de peticiones excedido (HTTP 429) al descargar datos para playa %s.",
                playa_id,
            )
            return None

        if resp_paso2.status_code == 404:
            logger.warning(
                "Datos no encontrados (HTTP 404) en la URL temporal de AEMET para playa %s.",
                playa_id,
            )
            return None

        resp_paso2.raise_for_status()

        return _decodificar_json_aemet(resp_paso2)

    except Timeout:
        logger.warning(
            "Timeout (%ss) al consultar AEMET para playa %s.",
            timeout,
            playa_id,
        )
        return None
    except requests.HTTPError as exc:
        codigo = exc.response.status_code if exc.response is not None else "desconocido"
        logger.warning(
            "Error HTTP (%s) al consultar AEMET para playa %s: %s",
            codigo,
            playa_id,
            exc,
        )
        return None
    except ValueError as exc:
        logger.warning(
            "Error al parsear JSON de AEMET para playa %s: %s",
            playa_id,
            exc,
        )
        return None
    except RequestException as exc:
        logger.warning(
            "Error de conexión con AEMET para playa %s: %s",
            playa_id,
            exc,
        )
        return None