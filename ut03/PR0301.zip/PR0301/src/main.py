
import io
import logging
import pandas as pd
import requests
import json

from aemet_client import obtener_prediccion_playa
from datetime import datetime, timezone
from pathlib import Path
from s3_manager import get_boto3_client, upload_file_to_s3
from config import (
    api_key,
    bucket_name,
    aws_access_key_id,
    aws_secret_access_key,
    aws_session_token,
    aws_default_region
)

def obtener_ids_playa_por_municipios(
    csv_path: str | Path,
    codigos_ine: list[str],
    max_playas: int = 15,
    columna_municipio: str = "ID_MUNICIPIO",
    columna_playa: str = "ID_PLAYA",
    encoding: str = "utf-8-sig",
    sep: str | None = None,
) -> list[str]:
    """
    Filtra playas_codigos.csv quedándose con las playas cuyo ID_MUNICIPIO esté en
    codigos_ine (normalizados a 5 cifras), limita a un máximo de max_playas y
    devuelve una lista única de ID_PLAYA de 7 dígitos.
    """
    ruta = Path(csv_path)
    if not ruta.is_file():
        raise FileNotFoundError(f"No se encuentra el fichero CSV: {ruta}")

    if max_playas < 0:
        raise ValueError("max_playas no puede ser negativo.")

    if max_playas == 0 or not codigos_ine:
        return []

    df = pd.read_csv(
    ruta,
    sep=sep,
    encoding="latin-1",  # o "cp1252" si ves caracteres raros en comillas/guiones
    engine="python" if sep is None else "c",
)

    df.columns = [col.strip() for col in df.columns]

    for col in (columna_municipio, columna_playa):
        if col not in df.columns:
            raise KeyError(
                f"No se encontró la columna '{col}'. "
                f"Columnas disponibles: {list(df.columns)}"
            )

    municipios_objetivo = {
        str(codigo).strip().zfill(5)
        for codigo in codigos_ine
        if str(codigo).strip()
    }

    serie_limpia = df[columna_municipio].astype("string").str.strip()
    serie_muni = (
        serie_limpia
        .fillna("")
        .str.strip()
        .str.replace(r"\.0$", "", regex=True)
    )
    serie_muni = serie_muni[serie_muni != ""].str.zfill(5)

    mask = df.index.isin(serie_muni[serie_muni.isin(municipios_objetivo)].index)

    serie_limpia_2 = df.loc[mask, columna_playa].astype("string").str.strip()
    playas = (
        serie_limpia_2
        .dropna()
        .str.strip()
        .str.replace(r"\.0$", "", regex=True)
    )
    playas = playas[playas != ""].str.zfill(7)

    # Conserva el orden de aparición, elimina duplicados y aplica el límite máximo
    ids_unicos = list(dict.fromkeys(playas.tolist()))
    return ids_unicos[:max_playas]

def obtener_codigos_ine_provincia_df(
    csv_path: str | Path,
    provincia: str,
    columna_provincia: str = "Provincia",
    columna_ine: str = "Código_IN",
    encoding: str = "utf-8-sig",
    sep: str | None = None,
) -> list[str]:
    """
    Lee un CSV de playas con pandas, filtra por provincia y devuelve el listado
    único y ordenado de códigos INE de municipio normalizados a 5 cifras con ceros
    a la izquierda.
    """
    ruta = Path(csv_path)
    if not ruta.is_file():
        raise FileNotFoundError(f"No se encuentra el fichero CSV: {ruta}")

    df = pd.read_csv(
        ruta,
        dtype=str,
        encoding=encoding,
        sep=sep,
        engine="python" if sep is None else "c",
    )

    df.columns = [col.strip() for col in df.columns]

    for col in (columna_provincia, columna_ine):
        if col not in df.columns:
            raise KeyError(
                f"No se encontró la columna '{col}'. "
                f"Columnas disponibles: {list(df.columns)}"
            )

    provincia_objetivo = provincia.strip().casefold()

    serie_prov = df[columna_provincia].fillna("").str.strip().str.casefold()
    codigos = (
        df.loc[serie_prov == provincia_objetivo, columna_ine]
        .dropna()
        .str.strip()
    )
    codigos = codigos[codigos != ""].str.zfill(5)

    return sorted(codigos.unique().tolist())
def build_s3_playa_key(
    id_playa: str,
    now: datetime | None = None,
    base_prefix: str = "",
) -> str:
    """
    Construye la clave en S3 con partición por fecha actual y marca temporal HHMMSS:
    [base_prefix/]year=YYYY/month=MM/day=DD/pred_playa_<ID_PLAYA>_<HHMMSS>.json
    """
    ref_time = now if now is not None else datetime.now(timezone.utc)
    partition = (
        f"year={ref_time:%Y}/"
        f"month={ref_time:%m}/"
        f"day={ref_time:%d}"
    )
    filename = f"pred_playa_{id_playa}_{ref_time:%H%M%S}.json"
    prefix = base_prefix.strip("/")
    return f"{prefix}/{partition}/{filename}" if prefix else f"{partition}/{filename}"


def run_pipeline(
    bucket_name: str,
    provincia: str,
    playas_csv: str = "playas.csv",
    playas_codigos_csv: str = "playas_codigos.csv",
    max_playas: int = 15,
    region_name: str | None = None,
    aemet_api_key: str | None = None,
    base_prefix: str = "",
) -> list[str]:
    """
    Orquesta la obtención de ID_PLAYA, descarga desde AEMET y subida directa
    desde memoria RAM a S3. Devuelve las claves (Key) subidas correctamente.
    """
    logger = logging.getLogger(__name__)
    codigos_ine = obtener_codigos_ine_provincia_df(
        csv_path=playas_csv,
        provincia=provincia,
    )
    ids_playa = obtener_ids_playa_por_municipios(
        csv_path=playas_codigos_csv,
        codigos_ine=codigos_ine,
        max_playas=max_playas,
    )

    if not ids_playa:
        logger.warning("No se encontraron ID_PLAYA para la provincia '%s'.", provincia)
        return []

    s3_client = get_boto3_client(service_name="s3", region_name=region_name)
    uploaded_keys: list[str] = []

    with requests.Session() as session:
        for id_playa in ids_playa:
            prediccion = obtener_prediccion_playa(
                id_playa=id_playa,
                session=session,
            )
            if prediccion is None:
                continue

            ahora = datetime.now(timezone.utc)
            timestamp_iso = ahora.strftime("%Y-%m-%dT%H:%M:%SZ")
            s3_key = build_s3_playa_key(
                id_playa=id_playa,
                now=ahora,
                base_prefix=base_prefix,
            )

            # Serializa directamente en memoria RAM (sin tocar disco)
            json_bytes = json.dumps(
                prediccion,
                ensure_ascii=False,
                indent=2,
            ).encode("utf-8")

            s3_client.put_object(
                Bucket=bucket_name,
                Key=s3_key,
                Body=json_bytes,
                ContentType="application/json",
                Metadata={"source": "AEMET_API", "ingestion_timestamp": timestamp_iso},
            )
            uploaded_keys.append(s3_key)
            logger.info("Subido a s3://%s/%s", bucket_name, s3_key)

    return uploaded_keys


def main() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )
    logger = logging.getLogger(__name__)
    s3 = get_boto3_client("s3", aws_access_key_id=aws_access_key_id , aws_secret_access_key=aws_secret_access_key , aws_session_token=aws_session_token , region_name=aws_default_region)

    logger.warning(f"Objeto cliente s3: {s3}")

    ingestion_timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    # Subir un único fichero
    uploaded_key = upload_file_to_s3(
        s3_client=s3,
        local_path="../data/playas.csv",
        bucket_name=bucket_name,
        s3_key="bronce/catalogos/miteco_playas/v1/playas.csv",
        metadata={"source": "MITECO_OpenData", "ingestion_timestamp": ingestion_timestamp,},
    )

    logger.warning(f"Subido como: {uploaded_key}")

    uploaded_key = upload_file_to_s3(
        s3_client=s3,
        local_path="../data/playas_codigos.csv",
        bucket_name=bucket_name,
        s3_key="bronce/catalogos/aemet_codigos/v1/playas_codigos.csv",
        metadata={"source": "AEMET_Catalogo", "ingestion_timestamp": ingestion_timestamp,},
    )

    logger.warning(f"Subido como: {uploaded_key}")

    codigos_ine = obtener_codigos_ine_provincia_df(
        csv_path="../data/playas.csv",
        provincia="Almería",
    )

    logger.warning(f"Municipios únicos ({len(codigos_ine)}): {codigos_ine}")

    base_prefix = "bronce/meteorologia/aemet_prediccion_playas/"

    # Cargar las provincias únicas desde el CSV (ajusta el nombre de la columna si difiere, ej. 'Provincia' o 'PROVINCIA')
    df = pd.read_csv("../data/playas.csv", sep=None, engine="python")
    provincias = sorted(df["Provincia"].dropna().unique())

    # Mostrar opciones numeradas
    print("Selecciona una provincia:")
    for i, provincia in enumerate(provincias, start=1):
        print(f"  {i}. {provincia}")

    # Pedir y validar la elección del usuario
    while True:
        opcion = input("\nIntroduce el número de la provincia: ").strip()
        if opcion.isdigit() and 1 <= int(opcion) <= len(provincias):
            provincia_elegida = provincias[int(opcion) - 1]
            break
        print(f"Opción no válida. Introduce un número entre 1 y {len(provincias)}.")

    print(f"\nHas seleccionado: {provincia_elegida}")

    subidas = run_pipeline(
        bucket_name=bucket_name,
        provincia=provincia_elegida,
        playas_csv="../data/playas.csv",
        playas_codigos_csv="../data/playas_codigos.csv",
        max_playas=15,
        region_name=aws_default_region,
        base_prefix=base_prefix,
    )
    logger.info("Proceso finalizado. Total ficheros subidos a S3: %d", len(subidas))


if __name__ == "__main__":
    main()