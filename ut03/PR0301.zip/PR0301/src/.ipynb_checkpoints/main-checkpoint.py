from s3_manager import get_boto3_client, upload_file_to_s3, upload_bytes_to_s3
import io

from config import (
    api_key,
    bucket_name,
    aws_access_key_id,
    aws_secret_access_key,
    aws_session_token,
    aws_default_region
)

s3 = get_boto3_client("s3", aws_access_key_id=aws_access_key_id , aws_secret_access_key=aws_secret_access_key , aws_session_token=aws_session_token , region_name=aws_default_region)

print(s3)


# Subir un único fichero
uploaded_key = upload_file_to_s3(
    s3_client=s3,
    local_path="./informes/ventas_2026.pdf",
    bucket_name="mi-bucket-privado",
    s3_key="2026/noviembre/ventas_2026.pdf",
)
print(f"Subido como: {uploaded_key}")


# 1. Subir un JSON serializado como str
payload_json = json.dumps({"evento": "alta_usuario", "activo": True}, indent=2)
upload_bytes_to_s3(
    s3_client=s3,
    data=payload_json,
    bucket_name="mi-bucket-privado",
    s3_key="eventos/2026/usuario.json",
)

# 3. Subir un buffer en memoria (por ejemplo, un CSV generado con csv o pandas)
csv_buffer = io.StringIO("id,nombre\n1,Ana\n2,Luis\n")
upload_bytes_to_s3(
    s3_client=s3,
    data=csv_buffer,
    bucket_name="mi-bucket-privado",
    s3_key="reportes/usuarios.csv",
)