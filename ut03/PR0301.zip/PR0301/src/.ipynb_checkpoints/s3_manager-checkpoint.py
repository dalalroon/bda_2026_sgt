from typing import Any
import io
import mimetypes
from pathlib import Path

import boto3
from botocore.config import Config
from botocore.exceptions import BotoCoreError, ClientError


def get_boto3_client(
    service_name: str,
    region_name: str | None = None,
    profile_name: str | None = None,
    aws_access_key_id: str | None = None,
    aws_secret_access_key: str | None = None,
    aws_session_token: str | None = None,
    endpoint_url: str | None = None,
    max_attempts: int = 3,
    connect_timeout: int = 10,
    read_timeout: int = 30,
) -> Any:
    """Crea y devuelve un cliente configurado de boto3 para el servicio indicado."""
    retry_config = Config(
        retries={"max_attempts": max_attempts, "mode": "standard"},
        connect_timeout=connect_timeout,
        read_timeout=read_timeout,
    )

    try:
        if profile_name or aws_access_key_id or aws_secret_access_key:
            session = boto3.Session(
                profile_name=profile_name,
                aws_access_key_id=aws_access_key_id,
                aws_secret_access_key=aws_secret_access_key,
                aws_session_token=aws_session_token,
                region_name=region_name,
            )
            return session.client(
                service_name=service_name,
                endpoint_url=endpoint_url,
                config=retry_config,
            )

        return boto3.client(
            service_name=service_name,
            region_name=region_name,
            endpoint_url=endpoint_url,
            config=retry_config,
        )
    except BotoCoreError as exc:
        raise RuntimeError(
            f"Error al crear el cliente de boto3 para '{service_name}': {exc}"
        ) from exc

def _normalize_s3_metadata(metadata: dict[str, Any]) -> dict[str, str]:
    """
    Normaliza los metadatos de usuario para S3:
    - Convierte claves a minúsculas (S3 las trata sin distinción de mayúsculas y las devuelve en minúsculas).
    - Convierte valores a str y valida que no haya saltos de línea ni caracteres no ASCII en cabeceras HTTP.
    """
    normalized: dict[str, str] = {}
    for raw_key, raw_value in metadata.items():
        clean_key = str(raw_key).strip().lower()
        clean_value = str(raw_value)

        if not clean_key:
            raise ValueError("Las claves de metadatos en S3 no pueden estar vacías.")
        if "\n" in clean_value or "\r" in clean_value:
            raise ValueError(
                f"El valor del metadato '{clean_key}' no puede contener saltos de línea."
            )

        normalized[clean_key] = clean_value

    return normalized


def upload_file_to_s3(
    s3_client: Any,
    local_path: str | Path,
    bucket_name: str,
    s3_key: str | None = None,
    content_type: str | None = None,
    metadata: dict[str, Any] | None = None,
    extra_args: dict[str, Any] | None = None,
) -> str:
    """
    Sube un fichero local a un bucket de S3 con metadatos opcionales
    y devuelve la clave (Key) final en el bucket.
    """
    file_path = Path(local_path)

    if not file_path.is_file():
        raise FileNotFoundError(f"El fichero local no existe o no es un archivo: {file_path}")

    # Si no se indica s3_key, usa el nombre del fichero
    key = s3_key.lstrip("/") if s3_key else file_path.name

    args: dict[str, Any] = dict(extra_args) if extra_args else {}

    # Detecta o aplica el Content-Type si no viene especificado en ExtraArgs
    if "ContentType" not in args:
        detected_type = content_type or mimetypes.guess_type(file_path.name)[0]
        if detected_type:
            args["ContentType"] = detected_type

    # Combina metadatos de extra_args (si existen) con los de `metadata`
    merged_metadata: dict[str, str] = {}
    if isinstance(args.get("Metadata"), dict):
        merged_metadata.update(_normalize_s3_metadata(args["Metadata"]))
    if metadata:
        merged_metadata.update(_normalize_s3_metadata(metadata))

    if merged_metadata:
        args["Metadata"] = merged_metadata

    try:
        if args:
            s3_client.upload_file(
                Filename=str(file_path),
                Bucket=bucket_name,
                Key=key,
                ExtraArgs=args,
            )
        else:
            s3_client.upload_file(
                Filename=str(file_path),
                Bucket=bucket_name,
                Key=key,
            )
        return key
    except (BotoCoreError, ClientError) as exc:
        raise RuntimeError(
            f"Error al subir '{file_path}' a 's3://{bucket_name}/{key}': {exc}"
        ) from exc
    
def _normalize_memory_data(
    data: bytes | bytearray | str | io.IOBase,
encoding: str = "utf-8",
) -> bytes | io.IOBase:
    """Convierte distintos tipos de datos en memoria a un formato compatible con boto3."""
    if isinstance(data, bytes):
        return data
    if isinstance(data, bytearray):
        return bytes(data)
    if isinstance(data, str):
        return data.encode(encoding)
    if hasattr(data, "read"):
        # Si es un stream de texto (como io.StringIO), lo convertimos a bytes en memoria
        if isinstance(data, io.TextIOBase):
            return io.BytesIO(data.read().encode(encoding))
        return data

    raise TypeError(
        "Tipo de dato no soportado en memoria. Usa bytes, bytearray, str o un stream con .read()."
    )


def upload_bytes_to_s3(
    s3_client: Any,
    data: bytes | bytearray | str | io.IOBase,
    bucket_name: str,
    s3_key: str,
    content_type: str | None = None,
    encoding: str = "utf-8",
    extra_args: dict[str, Any] | None = None,
) -> str:
    """
    Sube datos en memoria a un bucket de S3 y devuelve la clave (Key) final en el bucket.
    """
    if not s3_key or not s3_key.strip("/"):
        raise ValueError("Debes indicar una clave (s3_key) válida para el objeto en S3.")

    key = s3_key.lstrip("/")
    payload = _normalize_memory_data(data=data, encoding=encoding)

    args: dict[str, Any] = dict(extra_args) if extra_args else {}

    if "ContentType" not in args:
        detected_type = content_type or mimetypes.guess_type(key)[0]
        if detected_type:
            args["ContentType"] = detected_type

    try:
        # Si es un stream/file-like object, upload_fileobj maneja streams y subidas multiparte
        if hasattr(payload, "read"):
            if args:
                s3_client.upload_fileobj(
                    Fileobj=payload,
                    Bucket=bucket_name,
                    Key=key,
                    ExtraArgs=args,
                )
            else:
                s3_client.upload_fileobj(
                    Fileobj=payload,
                    Bucket=bucket_name,
                    Key=key,
                )
        else:
            # Para bytes ya cargados en memoria, put_object es directo y evita copias extra
            s3_client.put_object(
                Bucket=bucket_name,
                Key=key,
                Body=payload,
                **args,
            )

        return key
    except (BotoCoreError, ClientError) as exc:
        raise RuntimeError(
            f"Error al subir datos en memoria a 's3://{bucket_name}/{key}': {exc}"
        ) from exc