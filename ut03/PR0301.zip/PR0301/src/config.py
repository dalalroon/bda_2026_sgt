import os
from dotenv import load_dotenv

# Carga las variables del fichero .env en el entorno del sistema
load_dotenv("../.env")

# Recupera las variables con os.getenv()
api_key = os.getenv("AEMET_API_KEY")
bucket_name = os.getenv("S3_BUCKET_NAME")
aws_access_key_id = os.getenv("AWS_ACCESS_KEY_ID")
aws_secret_access_key = os.getenv("AWS_SECRET_ACCESS_KEY")
aws_session_token = os.getenv("AWS_SESSION_TOKEN")
aws_default_region = os.getenv("AWS_DEFAULT_REGION")

if not api_key or not bucket_name:
    raise ValueError("Faltan variables de entorno críticas en el archivo .env")